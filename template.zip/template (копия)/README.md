# Spring boot template

## Run
`sudo docker-compose up`
